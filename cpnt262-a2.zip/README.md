### CPNT 262: Web Client and Server Programming
## Course code and title:
CPNT 262: Web Client and Server Programming
## Author name:
Ariel Xiaomiao Zhang
## Assignment name:
Assignment 2 - Dynamic animals gallery
## Github repo:
[GH Pages](https://github.com/arielxiaomiaoz/cpnt262-a2)
[GH Repo](https://github.com/arielxiaomiaoz/cpnt262-a2)
## Comments:
For this assignment, my biggest challenge is my image doesn't work as I wish. I modified the path of the images for several times. 
## Attributions:
I reviewed some sample code by my instructor Tony Grimes.